const o=["Pediatrics","Gynaecology","Cardiology","Dermatology","General Medicine","Orthopedics","ENT","Ophthalmology","Psychiatry","Physiotherapy"];export{o as S};
